import { View, Text} from "react-native"

let Header = () => {
    return <View>
        <Text style={{color: "blue"}}>I am a Header</Text>
    </View>
}
export default Header;