import { Image, SafeAreaView, View, Text, ScrollView, ImageBackground, Button } from "react-native"

// const wonderman = require("./assets/images/bat1_tn.jpg")
// const antman = require("./assets/images/antman.jpg")
const hulk = require("./assets/images/hulk.jpg")
const herolist = [
  {color: "#ffb703", title: "Ironman", poster: require("./assets/images/ironman.jpg")},
  {color: "#023047", title: "batman", poster: require("./assets/images/batman.jpg")},
  {color: "#606c38", title: "superman", poster: require("./assets/images/superman.jpg")},
  {color: "#bc4749", title: "spiderman", poster: require("./assets/images/spiderman.jpg")},
  {color: "#6f1d1b", title: "rajani", poster: require("./assets/images/rajani.jpg")},
  {color: "#005f73", title: "hulk", poster: require("./assets/images/hulk.jpg")},
  {color: "#6d6875", title: "antman", poster: require("./assets/images/antman.jpg")}
]



export default App = () => {

  
  return <SafeAreaView>
    <View style={{marginTop: 20, marginLeft: 10, display: "flex",flexDirection:"row", marginBottom: 50}}>
       <Image style={{height: 20, width: 20,marginTop: 30}} source={{ uri: "https://cdn0.iconfinder.com/data/icons/social-messaging-ui-color-and-lines-1/2/51-512.png"}}/>
       <Text style={{display: "flex", marginLeft: 200, marginTop: 30}}>NEARBY TOURS</Text>
    </View>

    <ScrollView>
        <View style={{ display: "flex",flexDirection:"row", flexWrap: "wrap" }}>
        {herolist.map((val,idx)=> <View key={idx} style={{ margin: 10 }}>
          <ImageBackground style={{width:150, height:150, position:"relative"}} source={val.poster}>
            <Text style={{width:150 ,color:"white", position:"absolute", top:130, backgroundColor:"black", textAlign:"center"}}>{val.title}</Text>
          </ImageBackground>
        </View>)}
    </View>
    </ScrollView>
   
   
    
  </SafeAreaView>
}
