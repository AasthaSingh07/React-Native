import { View, Text, Image, Button, TextInput, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default Heroes = (props) => {
  let hero = props.route.params.Data;
  return (
    <SafeAreaView>
      <ScrollView>
      {hero.herolist.map((val, idx) => (
        <View key={idx} style={{ marginTop: 100 }}>
            <Image style={{width: 200, height: 200}} source= {{uri: val.poster}}/>
          <Text>{val.firstname + " " + val.lastname}</Text>
        </View>
      ))}
      </ScrollView>
    </SafeAreaView>
  );
};
