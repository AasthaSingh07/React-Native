import { View, Text, Image, Button} from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import Heroes from "./Heroes"


const Data = require("./../../hero.json")
export default HomeComp = (props) => {
    return <SafeAreaView>
        <View>
            <Button title="Heroes" onPress={()=>props.navigation.navigate("Heroes", {Data})}/>
        </View>
    </SafeAreaView>
}

