import { StyleSheet } from "react-native"

export const styles = StyleSheet.create({
    title : {
        fontSize: 20,
        textAlign : "center",
        fontWeight : "bold",
        backgroundColor : "silver",
        width: "100%"
    },
    poster: {
        width: 200,
        height: 200
    },
    container: {
        display: "flex", 
        justifyContent: "center", 
        alignItems: "center",
        gap: 10
    },
    input: {
        borderColor : "grey",
        borderWidth: 3,
        width: "70%",
        height: "10%"

    }
})