import { StatusBar } from 'expo-status-bar';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import HomeComp from "./components/screens/home";
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Heroes from './components/screens/Heroes';

/* 
Stack
Tab
Drawer 
*/

const Stack = createNativeStackNavigator();
export default function App() {
  return <NavigationContainer>
    {/* <Stack.Navigator initialRouteName='Wonderwoman'> */}
    <Stack.Navigator>
    <Stack.Screen name='Home' component={HomeComp}/>
    <Stack.Screen name='Heroes' component={Heroes}/>
    </Stack.Navigator>
  </NavigationContainer>
  
}

